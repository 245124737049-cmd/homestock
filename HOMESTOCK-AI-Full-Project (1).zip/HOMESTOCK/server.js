import express from "express";
import multer from "multer";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { GoogleGenAI } from "@google/genai";

dotenv.config();
const app = express();
const PORT = process.env.PORT || 3000;
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === "PASTE_YOUR_KEY_HERE") {
    console.error("Missing Gemini API key. Add it to the .env file as GEMINI_API_KEY=your_key");
    process.exit(1);
}
const ai = new GoogleGenAI({apiKey:process.env.GEMINI_API_KEY});
const upload = multer({
    storage:multer.memoryStorage(),
    limits:{fileSize:3 * 1024 * 1024, files:4},
    fileFilter:(req,file,cb) => {
        if (!["image/jpeg","image/png","image/webp"].includes(file.mimetype)) {
            return cb(new Error("Use JPG, PNG or WEBP product photos."));
        }
        cb(null,true);
    }
});

app.use(express.static(__dirname));
app.get("/", (req,res) => res.sendFile(path.join(__dirname,"index.html")));

app.post("/api/analyze-product", upload.array("photos",4), async (req,res) => {
    try {
        if (!req.files || req.files.length === 0) {
            return res.status(400).json({success:false,message:"Select at least one product photo."});
        }
        const prompt = `You are HOMESTOCK's product-label reading assistant. The images show the same product from different sides. Read only information that is visibly printed or clearly identifiable. Return ONLY valid JSON with exactly these fields: {"name":"","brand":"","manufacturer":"","category":"Other","barcode":"","manufacture":"","expiry":"","price":0,"description":""}. Use categories Kitchen, Groceries, Medicines, Beauty & Personal Care, Household Essentials, Electronics, Other. Convert clearly read dates to YYYY-MM-DD. Do not confuse MFG/manufacturing with EXP/expiry. Use price only when printed as MRP/price. Read barcode digits only if clear. Put product size and visible ingredients in description. If something is not visible or unclear, leave it empty (price 0). Never guess, infer a date, or invent manufacturer information.`;
        const parts = [{text:prompt}];
        for (const file of req.files) {
            parts.push({inlineData:{mimeType:file.mimetype,data:file.buffer.toString("base64")}});
        }
        const response = await ai.models.generateContent({
            model:"gemini-3.8-flash",
            contents:[{role:"user",parts}],
            config:{responseMimeType:"application/json"}
        });
        let product;
        try {
            product = JSON.parse(response.text || "{}");
        } catch {
            throw new Error("AI returned unreadable product details. Please try clearer photos.");
        }
        const allowed = ["Kitchen","Groceries","Medicines","Beauty & Personal Care","Household Essentials","Electronics","Other"];
        if (!allowed.includes(product.category)) product.category = "Other";
        product.price = Number(product.price) || 0;
        for (const key of ["name","brand","manufacturer","barcode","manufacture","expiry","description"]) {
            product[key] = String(product[key] || "").trim();
        }
        res.json({success:true,product});
    } catch (error) {
        console.error("Gemini product recognition error:",error);
        res.status(500).json({success:false,message:error.message || "Could not recognize product photos."});
    }
});

app.use((error,req,res,next) => {
    console.error(error);
    res.status(400).json({success:false,message:error.message || "Upload failed."});
});

app.listen(PORT,() => console.log(`HOMESTOCK is running at http://localhost:${PORT}`));

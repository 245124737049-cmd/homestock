(() => {
    const input = document.getElementById("productPhotoFiles");
    const button = document.getElementById("aiAnalyzeButton");
    const preview = document.getElementById("aiPhotoPreview");
    const status = document.getElementById("aiPhotoStatus");
    if (!input || !button || !preview || !status) return;

    let selectedFiles = [];
    let previewUrls = [];

    function makeSmallImage(file) {
        return new Promise((resolve, reject) => {
            const url = URL.createObjectURL(file);
            const image = new Image();
            image.onload = () => {
                const max = 1200;
                const scale = Math.min(1, max / Math.max(image.width, image.height));
                const canvas = document.createElement("canvas");
                canvas.width = Math.round(image.width * scale);
                canvas.height = Math.round(image.height * scale);
                canvas.getContext("2d").drawImage(image, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(blob => {
                    URL.revokeObjectURL(url);
                    if (!blob) return reject(new Error("Could not prepare photo."));
                    const reader = new FileReader();
                    reader.onload = () => resolve({blob, dataUrl:reader.result});
                    reader.onerror = reject;
                    reader.readAsDataURL(blob);
                }, "image/jpeg", 0.72);
            };
            image.onerror = () => { URL.revokeObjectURL(url); reject(new Error("Could not open one of the photos.")); };
            image.src = url;
        });
    }

    input.addEventListener("change", () => {
        previewUrls.forEach(URL.revokeObjectURL);
        previewUrls = [];
        selectedFiles = Array.from(input.files || []).slice(0, 4);
        preview.innerHTML = "";
        selectedFiles.forEach(file => {
            const url = URL.createObjectURL(file);
            previewUrls.push(url);
            const img = document.createElement("img");
            img.src = url;
            img.alt = "Selected product photo";
            preview.appendChild(img);
        });
        status.textContent = selectedFiles.length
            ? `${selectedFiles.length} photo(s) selected. Add front, back and side views if available.`
            : "No photos selected.";
    });

    button.addEventListener("click", async () => {
        if (!selectedFiles.length) {
            status.textContent = "Please select or take product photos first.";
            return;
        }
        button.disabled = true;
        status.textContent = "AI is reading your product photos. Please wait...";
        try {
            const images = await Promise.all(selectedFiles.map(makeSmallImage));
            const body = new FormData();
            images.forEach((item, index) => body.append("photos", item.blob, `product-${index + 1}.jpg`));
            const response = await fetch("/api/analyze-product", {method:"POST", body});
            const result = await response.json();
            if (!response.ok || !result.success) throw new Error(result.message || "AI could not read the photos.");

            const scope = angular.element(document.body).scope();
            if (!scope) throw new Error("HOMESTOCK page could not be found.");
            const photos = images.map(item => item.dataUrl);
            scope.$applyAsync(() => {
                scope.newProduct();
                Object.assign(scope.form, {
                    name:result.product.name || "",
                    brand:result.product.brand || "",
                    manufacturer:result.product.manufacturer || "",
                    category:result.product.category || "Other",
                    barcode:result.product.barcode || "",
                    manufacture:result.product.manufacture || "",
                    expiry:result.product.expiry || "",
                    price:Number(result.product.price || 0),
                    quantity:1,
                    minimum:1,
                    description:result.product.description || "",
                    images:photos,
                    image:photos[0] || ""
                });
                scope.page = "add";
                scope.editing = false;
            });
            const missing = [];
            if (!result.product.name) missing.push("name");
            if (!result.product.manufacturer) missing.push("manufacturer");
            if (!result.product.expiry) missing.push("expiry date");
            status.textContent = missing.length
                ? `Details detected. These could not be read: ${missing.join(", ")}. Please check before saving.`
                : "Product details detected. Please review them and save.";
        } catch (error) {
            console.error(error);
            status.textContent = error.message || "Photo recognition failed. Try clearer photos.";
        } finally {
            button.disabled = false;
        }
    });
})();

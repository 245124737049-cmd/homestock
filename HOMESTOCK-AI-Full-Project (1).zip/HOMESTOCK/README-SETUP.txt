HOMESTOCK AI - SETUP

1. Install Node.js 22 LTS or newer from https://nodejs.org/
2. Open this folder in VS Code.
3. Open Google AI Studio API Keys: https://aistudio.google.com/api-keys
4. Sign in, click Create API key (or Create key), choose/create a project, then copy the key.
5. In this folder, create a file named .env (same folder as server.js).
6. Put this inside .env: GEMINI_API_KEY=PASTE_YOUR_KEY_HERE
   Replace the words after = with your copied key. Do not share the key.
7. Open VS Code Terminal in this folder and run: npm install
8. Then run: npm start
9. Open http://localhost:3000 in Chrome. Do not use Live Server.

AI photos: open Scan Barcode, choose up to 4 photos of the same product, then click Recognize Product with AI. It fills the product form; review and save. It cannot read information that is hidden or blurry.

Account note: registration/login is a local demo flow in this browser, not secure production authentication. Product data is stored in browser LocalStorage.

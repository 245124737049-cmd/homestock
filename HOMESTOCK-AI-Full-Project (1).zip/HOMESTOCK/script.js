
var app = angular.module("homeStockApp", []);

app.controller("HomeController", function($scope, $timeout) {

    const STORAGE_KEY = "homestock_complete_v1";
    const USERS_KEY = "homestock_demo_users_v1";
    const SESSION_KEY = "homestock_demo_session_v1";

    $scope.isAuthenticated = !!localStorage.getItem(SESSION_KEY);
    $scope.authMode = $scope.isAuthenticated ? "" : "welcome";
    $scope.authForm = {name:"", email:"", password:"", confirmPassword:""};
    $scope.authError = "";
    $scope.authBusy = false;
    $scope.loggedInUser = JSON.parse(localStorage.getItem(SESSION_KEY) || "null");
    $scope.page = "dashboard";
    $scope.products = [];
    $scope.shoppingList = [];
    $scope.history = [];
    $scope.members = ["Me"];
    $scope.currentMember = "Me";
    $scope.newMember = "";
    $scope.monthlyBudget = 5000;
    $scope.darkMode = false;
    $scope.expiryNotifications = true;
    $scope.stockNotifications = true;
    $scope.toast = "";
    $scope.search = "";
    $scope.categoryFilter = "";
    $scope.sortBy = "name";
    $scope.barcodeInput = "";
    $scope.scanMessage = "";
    $scope.editing = false;
    $scope.scanner = null;

    // DEMO REGISTRATION AND LOGIN (browser-only; not production authentication)
    function getUsers() {
        try { return JSON.parse(localStorage.getItem(USERS_KEY) || "[]"); }
        catch (error) { return []; }
    }

    async function hashPassword(password, salt) {
        const data = new TextEncoder().encode(salt + ":" + password);
        const digest = await crypto.subtle.digest("SHA-256", data);
        return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2,"0")).join("");
    }

    $scope.showWelcome = function() {
        $scope.authMode = "welcome"; $scope.authError = "";
    };
    $scope.showRegister = function() {
        $scope.authMode = "register"; $scope.authError = "";
        $scope.authForm = {name:"", email:"", password:"", confirmPassword:""};
    };
    $scope.showLogin = function() {
        $scope.authMode = "login"; $scope.authError = "";
        $scope.authForm = {name:"", email:"", password:"", confirmPassword:""};
    };

    $scope.register = async function() {
        const name = String($scope.authForm.name || "").trim();
        const email = String($scope.authForm.email || "").trim().toLowerCase();
        const password = String($scope.authForm.password || "");
        if (!name || !email || password.length < 6) {
            $scope.authError = "Enter your name, a valid email and a password with at least 6 characters."; return;
        }
        if (password !== $scope.authForm.confirmPassword) {
            $scope.authError = "Passwords do not match."; return;
        }
        const users = getUsers();
        if (users.some(user => user.email === email)) {
            $scope.authError = "This email is already registered. Please login."; return;
        }
        $scope.authBusy = true; $scope.authError = "";
        try {
            const salt = crypto.randomUUID();
            const passwordHash = await hashPassword(password, salt);
            users.push({name, email, salt, passwordHash});
            localStorage.setItem(USERS_KEY, JSON.stringify(users));
            const session = {name, email};
            localStorage.setItem(SESSION_KEY, JSON.stringify(session));
            $scope.$applyAsync(function() {
                $scope.loggedInUser = session;
                $scope.isAuthenticated = true;
                $scope.authMode = "";
                $scope.page = "dashboard";
                notify("Account created. Welcome to HOMESTOCK!");
            });
        } catch (error) {
            $scope.$applyAsync(function() { $scope.authError = "Could not create account in this browser."; });
        } finally {
            $scope.$applyAsync(function() { $scope.authBusy = false; });
        }
    };

    $scope.login = async function() {
        const email = String($scope.authForm.email || "").trim().toLowerCase();
        const password = String($scope.authForm.password || "");
        const user = getUsers().find(item => item.email === email);
        if (!user) { $scope.authError = "Account not found. Please register first."; return; }
        $scope.authBusy = true; $scope.authError = "";
        try {
            const hash = await hashPassword(password, user.salt);
            if (hash !== user.passwordHash) {
                $scope.$applyAsync(function() { $scope.authError = "Incorrect password. Please try again."; });
                return;
            }
            const session = {name:user.name, email:user.email};
            localStorage.setItem(SESSION_KEY, JSON.stringify(session));
            $scope.$applyAsync(function() {
                $scope.loggedInUser = session;
                $scope.isAuthenticated = true;
                $scope.authMode = "";
                $scope.page = "dashboard";
                notify("Login successful. Welcome back!");
            });
        } catch (error) {
            $scope.$applyAsync(function() { $scope.authError = "Login could not be completed."; });
        } finally {
            $scope.$applyAsync(function() { $scope.authBusy = false; });
        }
    };

    $scope.logout = function() {
        $scope.stopScanner();
        localStorage.removeItem(SESSION_KEY);
        $scope.isAuthenticated = false;
        $scope.loggedInUser = null;
        $scope.authForm = {name:"", email:"", password:"", confirmPassword:""};
        $scope.authMode = "welcome";
        $scope.page = "dashboard";
    };

    $scope.categories = [
        {name:"Kitchen",icon:"🍚"},
        {name:"Groceries",icon:"🛒"},
        {name:"Medicines",icon:"💊"},
        {name:"Beauty & Personal Care",icon:"🧴"},
        {name:"Household Essentials",icon:"🧹"},
        {name:"Electronics",icon:"📱"},
        {name:"Other",icon:"📦"}
    ];

    function today() {
        const d = new Date();
        return [
            d.getFullYear(),
            String(d.getMonth()+1).padStart(2,"0"),
            String(d.getDate()).padStart(2,"0")
        ].join("-");
    }

    function parseDate(value) {
        if (!value) return null;
        const parts = value.split("-").map(Number);
        if (parts.length !== 3) return null;
        const d = new Date(parts[0], parts[1]-1, parts[2]);
        return isNaN(d.getTime()) ? null : d;
    }

    function daysUntil(value) {
        const d = parseDate(value);
        if (!d) return null;

        const now = new Date();
        now.setHours(0,0,0,0);
        return Math.round((d.getTime()-now.getTime())/86400000);
    }

    function monthKey(value) {
        return (value || "").slice(0,7);
    }

    function notify(message) {
        $scope.toast = message;
        $timeout(function() {
            $scope.toast = "";
        }, 2800);
    }

    $scope.persist = function() {
        const data = {
            products: $scope.products,
            shoppingList: $scope.shoppingList,
            history: $scope.history,
            members: $scope.members,
            monthlyBudget: $scope.monthlyBudget,
            darkMode: $scope.darkMode,
            expiryNotifications: $scope.expiryNotifications,
            stockNotifications: $scope.stockNotifications
        };

        try {
            localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
        } catch(error) {
            notify("Storage is full. Please export a backup.");
        }
    };

    function loadData() {
        try {
            const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");

            $scope.products = Array.isArray(saved.products) ? saved.products : [];
            $scope.shoppingList = Array.isArray(saved.shoppingList) ? saved.shoppingList : [];
            $scope.history = Array.isArray(saved.history) ? saved.history : [];
            $scope.members = Array.isArray(saved.members) && saved.members.length
                ? saved.members : ["Me"];

            $scope.monthlyBudget = Number(saved.monthlyBudget ?? 5000);
            $scope.darkMode = !!saved.darkMode;
            $scope.expiryNotifications = saved.expiryNotifications !== false;
            $scope.stockNotifications = saved.stockNotifications !== false;

        } catch(error) {
            $scope.products = [];
            $scope.shoppingList = [];
            $scope.history = [];
            $scope.members = ["Me"];
        }

        $scope.currentMember = $scope.members[0] || "Me";
    }

    loadData();

    $scope.go = function(page) {
        $scope.stopScanner();
        $scope.page = page;
        $scope.search = "";
        $scope.categoryFilter = "";
    };

    $scope.openCategory = function(category) {
        $scope.stopScanner();
        $scope.categoryFilter = category;
        $scope.search = "";
        $scope.page = "products";
    };

    $scope.toggleDark = function() {
        $scope.darkMode = !$scope.darkMode;
        $scope.persist();
    };

    // PRODUCT FORM

    function blankProduct() {
        return {
            name:"",
            brand:"",
            barcode:"",
            category:"Kitchen",
            manufacturer:"",
            manufacture:"",
            expiry:"",
            purchase:today(),
            openDate:"",
            price:0,
            quantity:1,
            minimum:1,
            location:"",
            member:$scope.currentMember,
            description:"",
            image:"",
            images:[]
        };
    }

    $scope.newProduct = function() {
        $scope.stopScanner();
        $scope.editing = false;
        $scope.form = blankProduct();
        $scope.page = "add";
    };

    $scope.editProduct = function(product) {
        $scope.stopScanner();
        $scope.editing = true;
        $scope.form = angular.copy(product);
        $scope.page = "add";
    };

    $scope.saveProduct = function() {
        if (!$scope.form || !$scope.form.name.trim()) {
            notify("Please enter the product name.");
            return;
        }

        if ($scope.form.quantity < 0 || $scope.form.price < 0) {
            notify("Quantity and price cannot be negative.");
            return;
        }

        const barcode = String($scope.form.barcode || "").trim();

        const duplicate = $scope.products.find(function(p) {
            return barcode && String(p.barcode || "").trim() === barcode
                && p.id !== $scope.form.id;
        });

        if (duplicate) {
            if (!confirm(
                "This barcode already exists for " + duplicate.name +
                ". Do you want to update its quantity instead?"
            )) return;

            duplicate.quantity = Number(duplicate.quantity || 0) +
                Number($scope.form.quantity || 0);

            duplicate.price = Number($scope.form.price || duplicate.price);
            $scope.persist();
            $scope.go("products");
            notify("Existing product quantity updated.");
            return;
        }

        const product = angular.copy($scope.form);
        product.quantity = Number(product.quantity || 0);
        product.price = Number(product.price || 0);
        product.minimum = Number(product.minimum ?? 1);
        product.barcode = barcode;

        if ($scope.editing) {
            const index = $scope.products.findIndex(p => p.id === product.id);

            if (index !== -1) {
                $scope.products[index] = product;
            }

            notify("Product updated successfully.");

        } else {
            product.id = Date.now() + Math.random().toString(16).slice(2);
            product.createdAt = today();
            $scope.products.push(product);

            $scope.history.unshift({
                name:product.name,
                action:"Added to home inventory",
                date:today(),
                quantity:product.quantity,
                member:product.member || $scope.currentMember
            });

            notify("Product added to your home!");
        }

        $scope.persist();
        $scope.go("products");
    };

    $scope.deleteProduct = function(product) {
        if (!confirm("Delete " + product.name + " from your home inventory?")) return;

        $scope.products = $scope.products.filter(p => p.id !== product.id);
        $scope.persist();
        notify("Product deleted.");
    };

    // PRODUCT SEARCH AND FILTERS

    $scope.filteredProducts = function() {
        let result = $scope.products.filter(function(p) {
            const query = ($scope.search || "").toLowerCase();

            const matchesSearch =
                (p.name || "").toLowerCase().includes(query) ||
                (p.brand || "").toLowerCase().includes(query) ||
                (p.barcode || "").toLowerCase().includes(query) ||
                (p.location || "").toLowerCase().includes(query);

            const matchesCategory =
                !$scope.categoryFilter ||
                p.category === $scope.categoryFilter;

            return matchesSearch && matchesCategory;
        });

        const key = $scope.sortBy;

        result.sort(function(a,b) {
            if (key === "price") return Number(b.price)-Number(a.price);
            if (key === "expiry") return (a.expiry || "9999").localeCompare(b.expiry || "9999");
            if (key === "purchase") return (b.purchase || "").localeCompare(a.purchase || "");
            return (a.name || "").localeCompare(b.name || "");
        });

        return result;
    };

    $scope.categoryCount = function(category) {
        return $scope.products.filter(p => p.category === category).length;
    };

    $scope.categoryPercent = function(category) {
        if (!$scope.products.length) return 0;
        return Math.round($scope.categoryCount(category) / $scope.products.length * 100);
    };

    $scope.inventoryValue = function() {
        return $scope.products.reduce(function(total,p) {
            return total + Number(p.price || 0) * Number(p.quantity || 0);
        },0);
    };

    $scope.totalUnits = function() {
        return $scope.products.reduce((total,p) => total + Number(p.quantity || 0),0);
    };

    // EXPIRY TRACKING

    $scope.expiryStatus = function(p) {
        if (!p.expiry) return "Date not entered";
        const days = daysUntil(p.expiry);
        if (days < 0) return "Expired";
        if (days === 0) return "Expires today";
        if (days <= 7) return "Expiring soon";
        if (days <= 30) return "Within 30 days";
        return "Safe for now";
    };

    $scope.expiryMessage = function(p) {
        if (!p.expiry) return "Expiry date not recorded";
        const days = daysUntil(p.expiry);
        if (days < -1) return "Expired " + Math.abs(days) + " days ago";
        if (days === -1) return "Expired 1 day ago";
        if (days === 0) return "Expires today";
        if (days === 1) return "Expires tomorrow";
        return "Expires in " + days + " days";
    };

    $scope.expiryClass = function(p) {
        const days = daysUntil(p.expiry);

        if (days === null) return "";
        if (days < 0) return "status-expired";
        if (days <= 7) return "status-expired";
        if (days <= 30) return "status-warning";

        return "status-good";
    };

    $scope.expiredCount = function() {
        return $scope.products.filter(p => p.expiry && daysUntil(p.expiry) < 0).length;
    };

    $scope.soonCount = function() {
        return $scope.products.filter(p =>
            p.expiry && daysUntil(p.expiry) >= 0 &&
            daysUntil(p.expiry) <= 30
        ).length;
    };

    $scope.withinSeven = function() {
        return $scope.products.filter(p =>
            p.expiry && daysUntil(p.expiry) >= 0 &&
            daysUntil(p.expiry) <= 7
        ).length;
    };

    $scope.expiryProducts = function() {
        return $scope.products.filter(p =>
            p.expiry && daysUntil(p.expiry) <= 30
        ).sort((a,b) => a.expiry.localeCompare(b.expiry));
    };

    $scope.alerts = function() {
        return $scope.expiryProducts().filter(p => p.expiry);
    };

    $scope.useFirst = function() {
        return $scope.products.filter(p =>
            p.expiry && daysUntil(p.expiry) >= 0 &&
            daysUntil(p.expiry) <= 30 &&
            Number(p.quantity) > 0
        ).sort((a,b) => a.expiry.localeCompare(b.expiry));
    };

    // STOCK MANAGEMENT

    $scope.lowProducts = function() {
        return $scope.products.filter(p =>
            Number(p.quantity || 0) <= Number(p.minimum ?? 1)
        );
    };

    $scope.lowCount = function() {
        return $scope.lowProducts().length;
    };

    $scope.productStatus = function(p) {
        if (p.expiry && daysUntil(p.expiry) < 0) return "Expired";
        if (Number(p.quantity) <= 0) return "Out of stock";
        if (Number(p.quantity) <= Number(p.minimum ?? 1)) return "Low stock";
        if (p.expiry && daysUntil(p.expiry) <= 30) return "Expiring soon";
        return "Available";
    };

    $scope.productStatusClass = function(p) {
        if (p.expiry && daysUntil(p.expiry) < 0) return "status-expired";
        if (Number(p.quantity) <= Number(p.minimum ?? 1)) return "status-warning";
        if (p.expiry && daysUntil(p.expiry) <= 30) return "status-warning";
        return "status-good";
    };

    $scope.consume = function(p) {
        if (Number(p.quantity) <= 0) {
            notify("This product is out of stock.");
            return;
        }

        const amount = Number(prompt(
            "How many units of " + p.name + " did you use?",
            "1"
        ));

        if (!Number.isInteger(amount) || amount <= 0) {
            notify("Please enter a valid quantity.");
            return;
        }

        if (amount > Number(p.quantity)) {
            notify("You don't have that many units.");
            return;
        }

        p.quantity -= amount;

        $scope.history.unshift({
            name:p.name,
            action:"Product used",
            date:today(),
            quantity:amount,
            member:$scope.currentMember
        });

        $scope.persist();
        notify("Product usage recorded.");
    };

    // BARCODE SCANNER

    $scope.startScanner = async function() {
        if (typeof Html5Qrcode === "undefined") {
            notify("Scanner library could not load. Check your internet.");
            return;
        }

        try {
            if (!$scope.scanner) {
                $scope.scanner = new Html5Qrcode("reader");
            }

            if ($scope.scanner.isScanning) return;

            await $scope.scanner.start(
                {facingMode:"environment"},
                {fps:10, qrbox:{width:250,height:140}},
                function(decodedText) {
                    $scope.$applyAsync(function() {
                        $scope.barcodeInput = decodedText;
                        $scope.scanMessage = "Barcode detected: " + decodedText;
                    });

                    $scope.stopScanner();
                    $scope.lookupProduct(decodedText);
                },
                function() {}
            );

            $scope.$applyAsync(function() {
                $scope.scanMessage = "Camera is active. Point it at a barcode.";
            });

        } catch(error) {
            $scope.$applyAsync(function() {
                $scope.scanMessage = "Camera unavailable. Use manual barcode entry.";
            });
        }
    };

    $scope.stopScanner = async function() {
        if (!$scope.scanner) return;

        try {
            if ($scope.scanner.isScanning) {
                await $scope.scanner.stop();
            }
        } catch(error) {}
    };

    // PRODUCT DATABASE LOOKUP

    $scope.lookupProduct = async function(code) {
        code = String(code || "").trim();

        if (!code) {
            notify("Please scan or enter a barcode.");
            return;
        }

        const existing = $scope.products.find(p =>
            String(p.barcode || "") === code
        );

        if (existing) {
            if (confirm(existing.name + " is already in your inventory. Edit it?")) {
                $scope.$applyAsync(function() {
                    $scope.editProduct(existing);
                });
            }
            return;
        }

        $scope.scanMessage = "Searching product database...";

        try {
            const response = await fetch(
                "https://world.openfoodfacts.org/api/v2/product/" +
                encodeURIComponent(code) +
                ".json"
            );

            if (!response.ok) throw new Error("Network error");

            const data = await response.json();

            if (data.status === 1 && data.product) {
                const p = data.product;

                $scope.$applyAsync(function() {
                    $scope.form = blankProduct();

                    $scope.form.barcode = code;
                    $scope.form.name =
                        p.product_name || p.product_name_en || "";

                    $scope.form.brand =
                        p.brands || "";

                    $scope.form.image =
                        p.image_front_url || p.image_url || "";

                    $scope.form.manufacturer =
                        p.manufacturing_places || "";

                    $scope.form.category =
                        "Groceries";

                    $scope.form.description =
                        p.generic_name || p.ingredients_text || "";

                    $scope.editing = false;
                    $scope.page = "add";
                    $scope.scanMessage = "Product found! Check the details and complete missing information.";

                    notify("Product details fetched.");
                });

            } else {
                $scope.$applyAsync(function() {
                    $scope.form = blankProduct();
                    $scope.form.barcode = code;
                    $scope.editing = false;
                    $scope.page = "add";
                    $scope.scanMessage = "Product not found. Please enter its details manually.";
                    notify("Barcode recorded. Add product details.");
                });
            }

        } catch(error) {
            $scope.$applyAsync(function() {
                $scope.form = blankProduct();
                $scope.form.barcode = code;
                $scope.editing = false;
                $scope.page = "add";
                notify("Database unavailable. You can enter product details manually.");
            });
        }
    };

    // SHOPPING LIST

    $scope.shoppingInput = {
        name:"",
        quantity:1,
        price:0
    };

    $scope.addShoppingItem = function() {
        if (!$scope.shoppingInput.name.trim()) return;

        $scope.shoppingList.push({
            id:Date.now() + Math.random(),
            name:$scope.shoppingInput.name.trim(),
            quantity:Number($scope.shoppingInput.quantity || 1),
            price:Number($scope.shoppingInput.price || 0),
            done:false
        });

        $scope.shoppingInput = {
            name:"",
            quantity:1,
            price:0
        };

        $scope.persist();
        notify("Added to shopping list.");
    };

    $scope.addToShopping = function(p) {
        const existing = $scope.shoppingList.find(i =>
            i.name.toLowerCase() === p.name.toLowerCase() && !i.done
        );

        if (existing) {
            notify("Already in your shopping list.");
            return;
        }

        $scope.shoppingList.push({
            id:Date.now() + Math.random(),
            name:p.name,
            quantity:1,
            price:p.price || 0,
            done:false
        });

        $scope.persist();
        notify(p.name + " added to shopping list.");
    };

    $scope.removeShopping = function(item) {
        $scope.shoppingList = $scope.shoppingList.filter(i => i.id !== item.id);
        $scope.persist();
    };

    $scope.clearCompleted = function() {
        $scope.shoppingList = $scope.shoppingList.filter(i => !i.done);
        $scope.persist();
        notify("Completed items removed.");
    };

    $scope.exportShopping = function() {
        let rows = [["Product","Quantity","Estimated Price","Purchased"]];
        $scope.shoppingList.forEach(i => {
            rows.push([i.name,i.quantity,i.price,i.done ? "Yes" : "No"]);
        });

        downloadCSV(rows,"homestock-shopping-list.csv");
    };

    // BUDGET AND PURCHASE TRACKING

    $scope.monthlySpent = function() {
        const currentMonth = today().slice(0,7);

        return $scope.products.reduce(function(total,p) {
            if (monthKey(p.purchase) === currentMonth) {
                return total + Number(p.price || 0) * Number(p.quantity || 0);
            }
            return total;
        },0);
    };

    $scope.budgetLeft = function() {
        return Number($scope.monthlyBudget || 0) - $scope.monthlySpent();
    };

    $scope.budgetPercent = function() {
        if (!$scope.monthlyBudget) return 0;

        return Math.min(100,Math.round(
            $scope.monthlySpent() / $scope.monthlyBudget * 100
        ));
    };

    $scope.monthlyPurchases = function() {
        const currentMonth = today().slice(0,7);

        return $scope.products.filter(p =>
            monthKey(p.purchase) === currentMonth
        );
    };

    $scope.recentPurchases = function() {
        return $scope.products.slice().sort((a,b) =>
            (b.purchase || "").localeCompare(a.purchase || "")
        ).slice(0,10);
    };

    // FAMILY MANAGEMENT

    $scope.addMember = function() {
        const name = ($scope.newMember || "").trim();

        if (!name) return;

        if ($scope.members.some(m => m.toLowerCase() === name.toLowerCase())) {
            notify("This member already exists.");
            return;
        }

        $scope.members.push(name);
        $scope.currentMember = name;
        $scope.newMember = "";
        $scope.persist();
        notify("Family member added.");
    };

    $scope.memberCount = function(name) {
        return $scope.products.filter(p => p.member === name).length;
    };

    $scope.removeMember = function(name) {
        if ($scope.memberCount(name) > 0) {
            notify("Reassign or remove their products before removing this member.");
            return;
        }

        if (!confirm("Remove " + name + "?")) return;

        $scope.members = $scope.members.filter(m => m !== name);
        $scope.currentMember = $scope.members[0] || "Me";
        $scope.persist();
    };

    // CSV EXPORT

    function downloadCSV(rows, filename) {
        const content = "\uFEFF" + rows.map(row =>
            row.map(value =>
                '"' + String(value ?? "").replace(/"/g,'""') + '"'
            ).join(",")
        ).join("\r\n");

        const blob = new Blob([content],{
            type:"text/csv;charset=utf-8;"
        });

        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");

        a.href = url;
        a.download = filename;
        a.click();

        URL.revokeObjectURL(url);
    }

    $scope.exportCSV = function() {
        const fields = [
            "name","brand","barcode","category","manufacturer",
            "manufacture","expiry","purchase","openDate","price",
            "quantity","minimum","location","member","description"
        ];

        const rows = [fields];

        $scope.products.forEach(p => {
            rows.push(fields.map(f => p[f] ?? ""));
        });

        downloadCSV(rows,"homestock-products.csv");
        notify("CSV report downloaded.");
    };

    // CSV IMPORT

    function parseCSV(text) {
        const rows = [];
        let row = [];
        let field = "";
        let quoted = false;

        for (let i=0; i<text.length; i++) {
            const ch = text[i];

            if (ch === '"' && quoted && text[i+1] === '"') {
                field += '"';
                i++;
            } else if (ch === '"') {
                quoted = !quoted;
            } else if (ch === "," && !quoted) {
                row.push(field);
                field = "";
            } else if ((ch === "\n" || ch === "\r") && !quoted) {
                if (ch === "\r" && text[i+1] === "\n") i++;
                row.push(field);
                if (row.some(v => v !== "")) rows.push(row);
                row = [];
                field = "";
            } else {
                field += ch;
            }
        }

        row.push(field);
        if (row.some(v => v !== "")) rows.push(row);

        return rows;
    }

    $scope.documentImport = function() {
        document.getElementById("importFile").click();
    };

    document.getElementById("importFile").addEventListener("change",function(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = function(e) {
            try {
                const rows = parseCSV(e.target.result);
                const headers = rows.shift().map(h => h.trim());

                const imported = rows.map(row => {
                    let p = blankProduct();

                    headers.forEach((h,index) => {
                        if (Object.prototype.hasOwnProperty.call(p,h)) {
                            p[h] = row[index] || "";
                        }
                    });

                    p.price = Number(p.price || 0);
                    p.quantity = Number(p.quantity || 0);
                    p.minimum = Number(p.minimum ?? 1);
                    p.id = Date.now() + Math.random();

                    return p;
                }).filter(p => p.name);

                imported.forEach(p => {
                    const existing = $scope.products.find(old =>
                        p.barcode && old.barcode === p.barcode
                    );

                    if (!existing) $scope.products.push(p);
                });

                $scope.$applyAsync(function() {
                    $scope.persist();
                    notify(imported.length + " CSV records processed.");
                });

            } catch(error) {
                alert("Could not read this CSV file.");
            }

            event.target.value = "";
        };

        reader.readAsText(file);
    });

    // FULL BACKUP AND RESTORE

    $scope.exportJSON = function() {
        const backup = {
            products:$scope.products,
            shoppingList:$scope.shoppingList,
            history:$scope.history,
            members:$scope.members,
            monthlyBudget:$scope.monthlyBudget,
            darkMode:$scope.darkMode,
            expiryNotifications:$scope.expiryNotifications,
            stockNotifications:$scope.stockNotifications
        };

        const blob = new Blob(
            [JSON.stringify(backup,null,2)],
            {type:"application/json"}
        );

        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");

        a.href = url;
        a.download = "homestock-backup.json";
        a.click();

        URL.revokeObjectURL(url);
        notify("Full backup downloaded.");
    };

    $scope.documentRestore = function() {
        document.getElementById("restoreFile").click();
    };

    document.getElementById("restoreFile").addEventListener("change",function(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();

        reader.onload = function(e) {
            try {
                const backup = JSON.parse(e.target.result);

                if (!Array.isArray(backup.products)) {
                    throw new Error("Invalid backup");
                }

                if (!confirm("Restore backup? Current household data will be replaced.")) return;

                $scope.$applyAsync(function() {
                    $scope.products = backup.products;
                    $scope.shoppingList = Array.isArray(backup.shoppingList) ? backup.shoppingList : [];
                    $scope.history = Array.isArray(backup.history) ? backup.history : [];
                    $scope.members = Array.isArray(backup.members) && backup.members.length
                        ? backup.members : ["Me"];

                    $scope.monthlyBudget = Number(backup.monthlyBudget || 5000);
                    $scope.darkMode = !!backup.darkMode;
                    $scope.expiryNotifications = backup.expiryNotifications !== false;
                    $scope.stockNotifications = backup.stockNotifications !== false;
                    $scope.currentMember = $scope.members[0];

                    $scope.persist();
                    notify("Backup restored successfully.");
                });

            } catch(error) {
                alert("Invalid backup file.");
            }

            event.target.value = "";
        };

        reader.readAsText(file);
    });

    // PRINT / PDF REPORT

    $scope.printReport = function() {
        let html = `
        <html>
        <head>
        <title>HOMESTOCK Household Report</title>
        <style>
        body{font-family:Arial;padding:25px;color:#26372f}
        h1{color:#397b65}
        table{width:100%;border-collapse:collapse;margin-top:20px}
        th,td{border:1px solid #ddd;padding:9px;text-align:left}
        th{background:#eaf3ed}
        </style>
        </head>
        <body>
        <h1>HOMESTOCK</h1>
        <h2>Household Inventory Report</h2>
        <p>Generated: ${today()}</p>
        <p>Total Products: ${$scope.products.length}</p>
        <p>Inventory Value: ₹${$scope.inventoryValue().toFixed(2)}</p>
        <table>
        <tr><th>Product</th><th>Category</th><th>Quantity</th><th>Expiry</th><th>Location</th></tr>
        `;

        $scope.products.forEach(p => {
            html += `<tr>
                <td>${escapeHTML(p.name)}</td>
                <td>${escapeHTML(p.category)}</td>
                <td>${Number(p.quantity)}</td>
                <td>${escapeHTML(p.expiry || "Not entered")}</td>
                <td>${escapeHTML(p.location || "")}</td>
            </tr>`;
        });

        html += `</table></body></html>`;

        const win = window.open("", "_blank");

        if (!win) {
            notify("Allow pop-ups to print your report.");
            return;
        }

        win.document.write(html);
        win.document.close();
        win.onload = function() {
            win.print();
        };
    };

    function escapeHTML(value) {
        return String(value ?? "").replace(/[&<>"']/g,function(ch) {
            return {
                "&":"&amp;",
                "<":"&lt;",
                ">":"&gt;",
                '"':"&quot;",
                "'":"&#39;"
            }[ch];
        });
    }

    // BROWSER NOTIFICATIONS

    $scope.enableNotifications = async function() {
        if (!("Notification" in window)) {
            notify("This browser does not support notifications.");
            return;
        }

        const permission = await Notification.requestPermission();

        if (permission === "granted") {
            notify("Browser notifications enabled.");
            $scope.checkNotifications();
        } else {
            notify("Notification permission was not granted.");
        }
    };

    $scope.checkNotifications = function() {
        if (!("Notification" in window) || Notification.permission !== "granted") return;

        if ($scope.expiryNotifications) {
            $scope.products.forEach(p => {
                const days = daysUntil(p.expiry);

                if (days !== null && days >= 0 && days <= 7) {
                    new Notification("HOMESTOCK Expiry Reminder",{
                        body:p.name + " expires in " + days + " day(s)."
                    });
                }
            });
        }

        if ($scope.stockNotifications) {
            $scope.lowProducts().forEach(p => {
                new Notification("HOMESTOCK Low Stock",{
                    body:p.name + " needs restocking."
                });
            });
        }
    };

    // SETTINGS

    $scope.clearAll = function() {
        if (!confirm("This will permanently delete all HOMESTOCK data from this browser. Continue?")) return;

        if (!confirm("Are you absolutely sure? Download a backup first if needed.")) return;

        localStorage.removeItem(STORAGE_KEY);
        location.reload();
    };

    // INITIAL SAVE AND STARTUP

    $scope.persist();

    $timeout(function() {
        $scope.checkNotifications();
    },1500);

});
